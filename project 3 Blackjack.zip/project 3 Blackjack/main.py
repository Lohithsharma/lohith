cards = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10]
import random
users_list=[]
computers_list=[]


def user_cards():
    users_list.append(random.choice(cards))


def computer_cards():
    computers_list.append(random.choice(cards))
def user_score():
    return sum(users_list)
def computer_score():
    return sum(computers_list)
def compare():
    if user_score() > 21:
        if 11 in users_list:
            users_list.remove("11")
            users_list.append("1")
    if user_score()<21 and computer_score()<21:
        if user_score() > computer_score():
            print("you win")
        elif computer_score() > user_score():
            print("you lost")
    else:
        print("Draw !!!!")
def play():
    a=input("Do you want to play a game of Blackjack? Type 'y' or 'n':")
    if a=='y':
        print('\n'*20)
        import art
        print(art.logo)
        user_cards()
        user_cards()
        computer_cards()
        print(f"your cards: {users_list}, current score:{user_score()}")
        print(f"computer's first card: {computer_score()}")
        draw=True
        while draw:
            c=input("Type 'y' to get another card, type 'n' to pass:")
            if c=='y':
                user_cards()
                print(f"your cards: {users_list},final score: {user_score()}")
                print(f"computer's first card: {computer_score()}")
                if user_score()>21:
                    print("you lost")
                    draw=False
                    break
            if c=='n':
                draw=False
                print(f"your final hand : {users_list}, final score: {user_score()}")
                computer_cards()
                if computer_score()<17:
                    computer_cards()
                    if computer_score()<17:
                        computer_cards()
                print(f"computer's final hand: {computers_list}, final score: {computer_score()}")
                if user_score()==21:
                    print('you won')
                elif computer_score()==21:
                    print("you lose")
                else:
                    compare()
    else:
        exit()
    play()
play()
