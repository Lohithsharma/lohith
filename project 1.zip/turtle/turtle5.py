import turtle as t
from turtle import Screen
import random
tim=t.Turtle()
t.colormode(255)
def colour():
    r=random.randint(0,255)
    g=random.randint(0,255)
    b=random.randint(0,255)
    a=(r,g,b)
    return a
def spiro(angle):
    for i in range(int(360/angle)):
        tim.color(colour())
        tim.speed(speed="fastest")
        tim.right(angle)
        tim.circle(100)
spiro(5)
screen=Screen()
screen.exitonclick()
