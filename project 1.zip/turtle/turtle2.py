import turtle as t
tim=t.Turtle()
for i in range(1,15):
    tim.fd(10)
    tim.penup()
    tim.fd(10)
    tim.pendown()
from turtle import Screen
screen=Screen()
screen.exitonclick()