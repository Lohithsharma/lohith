import random
from turtle import Screen
import turtle as t
tim=t.Turtle()
t.colormode(255)
def colour():
    r=random.randint(0,255)
    g=random.randint(0,255)
    b=random.randint(0,255)
    a=(r,g,b)
    return a
directions=[0.90,180,270]
for i in range(40):
    tim.pensize(15)
    tim.fd(20)
    tim.color(colour())
    tim.setheading(random.choice(directions))
    tim.speed(speed='fast')
screen=Screen()
screen.exitonclick()
