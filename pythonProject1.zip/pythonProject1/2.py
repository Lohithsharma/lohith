import turtle
from turtle import Turtle,Screen
import random
all_turtles=[]
game=True
screen=Screen()
y=[-100,-70,-40,-10,20,50]
colours=['red','blue','green','yellow','orange','purple']
move=[1,2,3,4,5,6,7,8,9,10]
turtle.setup(width=500,height=400)
user=screen.textinput(title="Turtle race",prompt="which colour do you want to choose(red,blue,green,yellow,orange,purple)")
print(f"You've selected a {user} turtle.")
for i in range(0,6):
    new_turtle = Turtle(shape="turtle")
    new_turtle.color(colours[i])
    new_turtle.penup()
    new_turtle.goto(-230,y[i])
    all_turtles.append(new_turtle)
while game:
    for i in all_turtles:
        if i.xcor()>230:
            game=False
            winning_color=i.pencolor()
            if winning_color==user:
                print(f"You've won.{winning_color} turtle won the race.")
            else:
                print(f"you've lost.{winning_color} turtle won the race.")
        distance=random.randint(1,10)
        i.fd(distance)
















screen.exitonclick()