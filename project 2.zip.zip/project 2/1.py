from turtle import Turtle,Screen
tim=Turtle()
def forward():
    tim.setheading(0)
    tim.fd(10)
def backward():
    tim.setheading(180)
    tim.fd(10)
def clockwise():
    tim.right(10)
    tim.fd(10)
def anticlockwise():
    tim.left(10)
    tim.fd(10)
def clear():
    tim.clear()
    tim.penup()
    tim.home()
    tim.pendown()
screen=Screen()
screen.listen()
screen.onkey(forward,key="w")
screen.onkey(backward,key="s")
screen.onkey(clockwise,key="d")
screen.onkey(anticlockwise,key="a")
screen.onkey(clear,key="c")


screen.exitonclick()


